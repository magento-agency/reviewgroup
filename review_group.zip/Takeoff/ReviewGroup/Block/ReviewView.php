<?php
namespace Takeoff\ReviewGroup\Block;

class ReviewView extends \Magento\Review\Block\Product\View
{


    
    public function getReviewsCollection()
    {
    
    	print_r('here');exit;
        $attribute = 'review_group';
        $attributeValue = $this->getProduct()->getData($attribute);
    
        $products = $this->getProductCollectionByAttribute($attribute,$attributeValue);
        $entity_ids = array();
        foreach ($products as $product){
            $entity_ids[]=$product->getId();
        }
        
        $reviews = $this->reviewFactory->create();
        $reviews->addStatusFilter( \Magento\Review\Model\Review::STATUS_APPROVED)
            ->addFieldToFilter('entity_id', 1)
            ->addFieldToFilter('entity_pk_value', array('in' => $entity_ids))
            ->setDateOrder()
            ->addRateVotes();
    
        return $reviews;
    }
    
    public function getProductCollectionByAttribute($attribute,$attributeValue)
    {
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        return $collection;
    }


}