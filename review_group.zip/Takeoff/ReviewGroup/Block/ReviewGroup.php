<?php
namespace Takeoff\ReviewGroup\Block;

class ReviewGroup extends \Magento\Framework\View\Element\Template
{

    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context  $context
     * @param array $data
     */

    protected $registry;
    protected $reviewFactory;
    protected $productCollectionFactory;
    
    public function __construct(  
        \Magento\Framework\Registry $registry,
        \Magento\Review\Model\RatingFactory $ratingFactory,
        \Magento\Review\Model\ResourceModel\Review\CollectionFactory $reviewFactory,
        \Magento\Review\Model\Review $review, 
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Framework\View\Element\Template\Context $context, 
        array $data = [])
    {
        $this->registry = $registry;
        $this->ratingFactory = $ratingFactory;
        $this->reviewFactory = $reviewFactory;
        $this->productCollectionFactory = $productCollectionFactory;
        parent::__construct($context, $data);
    }

    public function getReviews(){
        
        $attribute = 'review_group';
        $products = $this->getProductCollectionByAttribute($attribute);
        $entity_ids = array();
        foreach ($products as $product){
            $entity_ids[]=$product->getId();
        }
        
        $reviews = $this->reviewFactory->create();
        $reviews->addStatusFilter( \Magento\Review\Model\Review::STATUS_APPROVED)
            ->addFieldToFilter('entity_id', 1)
            ->addFieldToFilter('entity_pk_value', array('in' => $entity_ids))
            ->setDateOrder()
            ->addRateVotes();
            
        return $reviews;
    }
    
    
    public function getCurrentCategory()
    {        
        return $this->registry->registry('current_category');
    }
    
    
    
    public function getProductCollectionByAttribute($attribute)
    {
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        return $collection;
    }
    
}