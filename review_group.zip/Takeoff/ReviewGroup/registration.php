<?php
/**
 * Copyright © 2023 Takeoff Digital. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Takeoff_ReviewGroup',
    __DIR__
);
