<?php

declare(strict_types=1);

namespace Takeoff\ReviewGroup\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;
/**
 * Helper functions for other classes
 */
class Data extends AbstractHelper
{

 	public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
    	\Magento\Review\Model\ReviewFactory $reviewFactory
    )
    {
        $this->productCollectionFactory = $productCollectionFactory;
    	$this->reviewFactory = $reviewFactory;
    }

    /**
     * Get list of child/associated product ids
     *
     * @return  string (comma delimited list for grouped / configurable)
     */
     public function getProductIds($product)
     {
         if ($product instanceof \Magento\Catalog\Model\Product)
         {
         
        	$attribute = 'review_group';
        	$productIds = array();
        	$attributeValue = $product->getData($attribute);
        	
        	if ($attributeValue){
        	
                 //$productIds[]=$product->getId();    
        			$groupproducts = $this->getProductCollectionByAttribute($attribute,$attributeValue);
        	        foreach ($groupproducts as $groupproduct){
            			$productIds[]=$groupproduct->getId();
        			}     
                 
                 
                return (implode(',',$productIds));
        	
        	
        	} 

             return $product->getId();

         }

         return '0';
     }
     
     
     public function getProductRatings($product, $store_id = 0)
     {  
     	if ($product instanceof \Magento\Catalog\Model\Product)
         {
         
        	$attribute = 'review_group';
        	$rating = null;
        	$i = 0;
        	$attributeValue = $product->getData($attribute);
        	
        	if ($attributeValue){
        	
        			$groupproducts = $this->getProductCollectionByAttribute($attribute,$attributeValue);
        			
        	        foreach ($groupproducts as $groupproduct){
    					$this->reviewFactory->create()->getEntitySummary($groupproduct, $store_id);
    					$ratingSummary = $groupproduct->getRatingSummary()->getRatingSummary();
        	        	if ($ratingSummary > 0){
            			$rating = (float)$rating + (float)$ratingSummary;
            			$i++;
            			}
        			}     
                 	if ($i>0){
                 	$rating =  number_format($rating / $i , 2);
                 	}

        	} 

             return $rating;

         }

         return null;
     
     
     }
     
     
     
    public function getProductCollectionByAttribute($attribute,$attributeValue)
    {
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToFilter($attribute, $attributeValue)
        		   ->addAttributeToSelect('*');
        return $collection;
    }
}
