<?php
declare(strict_types=1);

namespace Takeoff\ReviewGroup\Plugin\Magento\Review\Block\Product;
use Takeoff\ReviewGroup\Helper\Data as Helper;

class ReviewRenderer
{
    /**
     * Review collection
     *
     * @var ReviewCollection
     */
    protected $_reviewsCollection;
    /**
     * Registry
     *
     * @var coreRegistry
     */
    protected $_coreRegistry;
    /**
     * Store Manager
     *
     * @var StoreManager
     */
    protected $_storeManager;
    /**
     * helper
     *
     * @var Helper
     */
    private $_helper;

    /**
     * Review resource model
     *
     * @var \Magento\Review\Model\ResourceModel\Review\CollectionFactory
     */
    protected $_reviewsColFactory;

    public function __construct(
        \Magento\Review\Model\ResourceModel\Review\CollectionFactory $collectionFactory,
        \Magento\Framework\Registry $registry,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        Helper $helper
    ) {
        $this->_reviewsColFactory = $collectionFactory;
        $this->_coreRegistry = $registry;
        $this->_storeManager = $storeManager;
        $this->_helper=$helper;
    }
    
    
    public function aroundGetRatingSummary(
        \Magento\Review\Block\Product\ReviewRenderer $subject,
        \Closure $proceed
    ) {
    
    	$product = $subject->getProduct();
    	
    	$mainrating = $product->getRatingSummary();
    	
        $averagerating = $this->_helper->getProductRatings($product, $this->_storeManager->getStore()->getId());
        
        if ($mainrating > $averagerating){
        	return $mainrating;
        } else {
        	return $averagerating;
        }
    }
    
    public function aroundGetReviewsCount(
        \Magento\Review\Block\Product\ReviewRenderer $subject,
        \Closure $proceed
    ) {
    
    	$product = $subject->getProduct();
    	
        $collection = $this->_reviewsColFactory->create()->addStoreFilter(
            $this->_storeManager->getStore()->getId()
        )->addStatusFilter(
            \Magento\Review\Model\Review::STATUS_APPROVED
        )->addEntityFilter(
            'product',
            $this->getProductIds($product)
        );

        return $collection->getSize();
    }

    /**
     * Get list of child/associated product ids
     *
     * @return  string (comma delimited list for grouped / configurable)
     */
    public function getProductIds($product)
    {
        return $this->_helper->getProductIds($product);
    }

    /**
     * Get store identifier
     *
     * @return  int
     */
    public function getStoreId()
    {
        return $this->_storeManager->getStore()->getId();
    }
}