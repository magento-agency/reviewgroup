<?php
declare(strict_types=1);

namespace Takeoff\ReviewGroup\Plugin\Magento\Review\Model\ResourceModel\Review\Product;

class Collection
{
    public function aroundAddEntityFilter(
        \Magento\Review\Model\ResourceModel\Review\Product\Collection $subject,
        \Closure $proceed,
        $entityId
    ) {
        $subject->getSelect()->where('rt.entity_pk_value in (?)', explode(',',$entityId));
         
        return $subject;

    }
}